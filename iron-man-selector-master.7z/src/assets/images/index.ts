import Alex from "./Alex.png";
import Chun from "./Chun.png";
import Dudley from "./Dudley.png";
import Elena from "./Elena.png";
import Gouki from "./Gouki.png";
import Hugo from "./Hugo.png";
import Ibuki from "./Ibuki.png";
import Ken from "./Ken.png";
import Makoto from "./Makoto.png";
import Necro from "./Necro.png";
import Oro from "./Oro.png";
import Q from "./Q.png";
import Remy from "./Remy.png";
import Ryu from "./Ryu.png";
import Sean from "./Sean.png";
import Twelve from "./Twelve.png";
import Urien from "./Urien.png";
import Yang from "./Yang.png";
import Yun from "./Yun.png";

const images: Record<string, any> = {
  Alex,
  Chun,
  Dudley,
  Elena,
  Gouki,
  Hugo,
  Ibuki,
  Ken,
  Makoto,
  Necro,
  Oro,
  Q,
  Remy,
  Ryu,
  Sean,
  Twelve,
  Urien,
  Yang,
  Yun,
};

export default images;
